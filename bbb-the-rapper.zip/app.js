const tracks = [
  {
    id: 1,
    name: "i walk quite gay",
    slug: "i-walk-quite-gay",
    url: "https://soundcloud.com/bbb-the-rapper/i-walk-quite-gay",
    date: "2026-05-30",
    embedUrl: "https://w.soundcloud.com/player/?url=https%3A//api.soundcloud.com/tracks/2167088442&color=%23ff5500&auto_play=true&hide_related=false&show_comments=true&show_user=true&show_reposts=false&show_teaser=true&visual=true"
  },
  {
    id: 2,
    name: "veggie beggie",
    slug: "veggie-beggie",
    url: "https://soundcloud.com/bbb-the-rapper/veggie-beggie",
    date: "2026-05-30",
    embedUrl: "https://w.soundcloud.com/player/?url=https%3A//soundcloud.com/bbb-the-rapper/veggie-beggie&color=%23ff5500&auto_play=true&hide_related=false&show_comments=true&show_user=true&show_reposts=false&show_teaser=true&visual=true"
  },
  {
    id: 3,
    name: "bbb in crib",
    slug: "final_mix",
    url: "https://soundcloud.com/bbb-the-rapper/final_mix",
    date: "2026-05-27",
    embedUrl: "https://w.soundcloud.com/player/?url=https%3A//soundcloud.com/bbb-the-rapper/final_mix&color=%23ff5500&auto_play=true&hide_related=false&show_comments=true&show_user=true&show_reposts=false&show_teaser=true&visual=true"
  },
  {
    id: 4,
    name: "jaja pindakass",
    slug: "jaja-pindakass",
    url: "https://soundcloud.com/bbb-the-rapper/jaja-pindakass",
    date: "2026-05-26",
    embedUrl: "https://w.soundcloud.com/player/?url=https%3A//soundcloud.com/bbb-the-rapper/jaja-pindakass&color=%23ff5500&auto_play=true&hide_related=false&show_comments=true&show_user=true&show_reposts=false&show_teaser=true&visual=true"
  }
];

function formatDate(dateStr) {
  const d = new Date(dateStr);
  return d.toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
}

function renderTracks() {
  const grid = document.getElementById('track-grid');
  grid.innerHTML = tracks.map((t, i) => `
    <div class="track-card" onclick="openTrack(${i})" tabindex="0" role="button" aria-label="Play ${t.name}">
      <div class="track-art">
        <div class="track-art-fallback">BBB</div>
        <div class="track-play-overlay">
          <div class="play-circle">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="white">
              <polygon points="5,3 19,12 5,21"/>
            </svg>
          </div>
        </div>
      </div>
      <div class="track-info">
        <div class="track-name">${t.name}</div>
        <div class="track-date">${formatDate(t.date)}</div>
      </div>
    </div>
  `).join('');
}

function openTrack(index) {
  const t = tracks[index];
  const modal = document.getElementById('modal');
  const content = document.getElementById('modal-content');
  content.innerHTML = `
    <h3 style="font-size:18px; font-weight:700; margin-bottom:1rem; padding-right:2rem;">${t.name}</h3>
    <iframe
      width="100%"
      height="300"
      scrolling="no"
      frameborder="no"
      allow="autoplay"
      src="${t.embedUrl}"
      style="border-radius:10px;"
    ></iframe>
    <div style="margin-top:1rem; display:flex; justify-content:space-between; align-items:center;">
      <span style="font-family:'Space Mono',monospace; font-size:11px; color:#888;">${formatDate(t.date)}</span>
      <a href="${t.url}" target="_blank" style="color:#ff5500; font-size:13px; font-weight:600; text-decoration:none;">
        Open on SoundCloud ↗
      </a>
    </div>
  `;
  modal.classList.add('open');
  modal.setAttribute('aria-hidden', 'false');
  document.body.style.overflow = 'hidden';
}

function closeModal() {
  const modal = document.getElementById('modal');
  modal.classList.remove('open');
  modal.setAttribute('aria-hidden', 'true');
  document.body.style.overflow = '';
  document.getElementById('modal-content').innerHTML = '';
}

document.addEventListener('keydown', e => {
  if (e.key === 'Escape') closeModal();
});

document.querySelectorAll('.track-card').forEach(card => {
  card.addEventListener('keydown', e => {
    if (e.key === 'Enter' || e.key === ' ') card.click();
  });
});

renderTracks();
