# BBB The Rapper – Fan Site

A sleek fan web app for **BBB The Rapper** (Ben Outikker, Breda NL) built with vanilla HTML, CSS, and JavaScript.

## Features

- Artist hero section with profile photo and stats
- Releases grid — click any track to open a SoundCloud player modal
- Full profile embed player
- About section
- Responsive mobile layout
- No frameworks, no build step needed

## Live on GitHub Pages

1. Push this repo to GitHub
2. Go to **Settings → Pages**
3. Set source to `main` branch, `/ (root)` folder
4. Your site will be live at `https://yourusername.github.io/bbb-the-rapper`

## Local preview

Just open `index.html` in your browser — no server needed.

## Artist links

- SoundCloud: https://soundcloud.com/bbb-the-rapper
